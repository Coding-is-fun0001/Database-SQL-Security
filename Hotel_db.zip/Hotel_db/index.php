<!DOCTYPE html>
<html>
<head>
    <title>Hotel Booking System</title>
    <style>
        body { font-family: Calibri; text-align: center; margin-top: 100px; }
        .btn { display: inline-block; padding: 12px 24px; margin: 10px; background: #007BFF; color: white; text-decoration: none; border-radius: 5px; font-size: 18px; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>🏨 Welcome to Hotel Booking System</h1>
    <a href="user.php" class="btn">👤 Users - Search and Booking rooms</a>
    <a href="admin.php" class="btn">🔧 Admin - Manage rooms</a>
</body>
</html>