<?php
session_start();
require_once 'db_connect.php';

$admin_password = 'admin123';

// Handle Login
if (isset($_POST['login'])) {
    if ($_POST['password'] === $admin_password) {
        $_SESSION['admin_logged'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $login_error = "密码错误";
    }
}

// Log out
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// if haven't login display login table list 
if (!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    ?>
    <!DOCTYPE html>
    <html>
    <head><title>Admin Login</title><style>body{font-family:Calibri;text-align:center;margin-top:100px;}</style></head>
    <body>
        <form method="post">
            <h2>Admin Login</h2>
            <input type="password" name="password" placeholder="password" required>
            <button type="submit" name="login">Login</button>
            <?php if(isset($login_error)) echo "<p style='color:red'>$login_error</p>"; ?>
        </form>
        <p>Default password: admin123</p>
    </body>
    </html>
    <?php
    exit;
}

// Add room
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $room_number = trim($_POST['room_number']);
    $room_type = trim($_POST['room_type']);
    $price = floatval($_POST['price']);
    $status = $_POST['status'];
    
    if ($room_number && $room_type && $price > 0) {
        $stmt = $pdo->prepare("INSERT INTO rooms (room_number, room_type, price, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$room_number, $room_type, $price, $status]);
        $success = "Add room success";
    } else {
        $error = "Please fill in complete information";
    }
}

// delete room
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    // check booking record
    $check = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE room_id = ?");
    $check->execute([$id]);
    if ($check->fetchColumn() > 0) {
        $error = "Room Booked，Can't Delete（Please delete record）";
    } else {
        $stmt = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
        $stmt->execute([$id]);
        $success = "Delete Success";
        // Refresh webpage
        header("Location: admin.php");
        exit;
    }
}

$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id")->fetchAll();
$bookings = $pdo->query("SELECT b.*, r.room_number FROM bookings b JOIN rooms r ON b.room_id = r.id ORDER BY b.booking_date DESC")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Room Management</title>
    <style>
        body { font-family: Calibri; width: 1200px; margin: auto; margin-top: 20px; }
        table, th, td { border: 1px solid #ccc; border-collapse: collapse; padding: 8px; text-align: left; }
        .form-section { border: 1px solid #aaa; padding: 15px; margin-bottom: 20px; background: #f0f0f0; }
        .delete { color: red; text-decoration: none; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>🔧 Admin Table</h1>
    <p><a href="?logout=1">Log out</a> | <a href="index.php">Back</a></p>
    
    <?php if (isset($success)) echo "<p class='success'>✅ $success</p>"; ?>
    <?php if (isset($error)) echo "<p class='error'>❌ $error</p>"; ?>
    
    <div class="form-section">
        <h2>➕ Add room（test insert）</h2>
        <form method="post">
            <input type="text" name="room_number" placeholder="Room Number (e.g 401)" required>
            <select name="room_type">
                <option value="Standard">Standard</option>
                <option value="Deluxe">Deluxe</option>
                <option value="Suite">Suite</option>
            </select>
            <input type="number" step="0.01" name="price" placeholder="Price (RM)" required>
            <select name="status">
                <option value="available">Available</option>
                <option value="booked">Booked</option>
            </select>
            <button type="submit" name="add">Add Room</button>
        </form>
    </div>
    
    <h2>📋 Room List</h2>
    <table>
        <tr><th>ID</th><th>Room Number</th><th>Type</th><th>Price(RM)</th><th>State</th><th>Operation</th></tr>
        <?php foreach ($rooms as $r): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= htmlspecialchars($r['room_number']) ?></td>
            <td><?= htmlspecialchars($r['room_type']) ?></td>
            <td><?= number_format($r['price'], 2) ?></td>
            <td><?= $r['status'] == 'available' ? 'Available' : 'Booked' ?></td>
            <td><a href="?delete=<?= $r['id'] ?>" class="delete" onclick="return confirm('Confirm Delete <?= htmlspecialchars($r['room_number']) ?> ？')">Delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <h2>📅 Booking Record</h2>
    <table>
        <tr><th>Booking ID</th><th>Room Number</th><th>Name</th><th>Phone Number</th><th>Check In</th><th>Check Out</th><th>Booking Time</th></tr>
        <?php foreach ($bookings as $b): ?>
        <tr>
            <td><?= $b['id'] ?></td>
            <td><?= htmlspecialchars($b['room_number']) ?></td>
            <td><?= htmlspecialchars($b['customer_name']) ?></td>
            <td><?= htmlspecialchars($b['customer_phone']) ?></td>
            <td><?= $b['checkin_date'] ?></td>
            <td><?= $b['checkout_date'] ?></td>
            <td><?= $b['booking_date'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>