<?php
require_once 'db_connect.php';

// Handle booking request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book'])) {
    $room_id = (int)$_POST['room_id'];
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    
    if ($name && $phone && $checkin && $checkout) {
        // insert booking record
        $stmt = $pdo->prepare("INSERT INTO bookings (room_id, customer_name, customer_phone, checkin_date, checkout_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$room_id, $name, $phone, $checkin, $checkout]);
        // Update room state as booked
        $update = $pdo->prepare("UPDATE rooms SET status = 'booked' WHERE id = ?");
        $update->execute([$room_id]);
        $success = "✅ Booking success！";
    } else {
        $error = "❌ Please fill in complete information";
    }
}

$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Users - Booking Room</title>
    <style>
        body { font-family: Calibri; width: 1000px; margin: auto; margin-top: 30px; }
        table, th, td { border: 1px solid #ccc; border-collapse: collapse; padding: 8px; text-align: left; }
        .available { color: green; font-weight: bold; }
        .booked { color: red; }
        .form-container { margin-top: 20px; border: 1px solid #aaa; padding: 15px; background: #f9f9f9; display: none; }
        .btn-cancel { background: #ccc; margin-left: 10px; }
    </style>
</head>
<body>
    <h1>🏨 Hotel rooms list - Users</h1>
    <a href="index.php">⬅ Back</a>
    <?php if (isset($success)) echo "<p style='color:green'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p style='color:red'>$error</p>"; ?>
    
    <table>
        <tr><th>Room Number</th><th>Type</th><th>Price</th><th>State</th><th>Operation</th></tr>
        <?php foreach ($rooms as $r): ?>
        <tr>
            <td><?= htmlspecialchars($r['room_number']) ?></td>
            <td><?= htmlspecialchars($r['room_type']) ?></td>
            <td>RM <?= number_format($r['price'], 2) ?></td>
            <td class="<?= $r['status'] ?>"><?= $r['status'] == 'available' ? '✅ available' : '❌ booked' ?></td>
            <td>
                <?php if ($r['status'] == 'available'): ?>
                    <button onclick="showBookForm(<?= $r['id'] ?>, '<?= htmlspecialchars($r['room_number']) ?>')">Booking</button>
                <?php else: ?>
                    <span style="color:gray;">Booked</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div id="bookForm" class="form-container">
        <h3>Booking room <span id="roomNumber"></span></h3>
        <form method="post">
            <input type="hidden" name="room_id" id="room_id">
            <div>Name: <input type="text" name="name" required></div>
            <div>Phone Number: <input type="text" name="phone" required></div>
            <div>Check In: <input type="date" name="checkin" required></div>
            <div>Check Out: <input type="date" name="checkout" required></div>
            <button type="submit" name="book">Confirm Booking</button>
            <button type="button" class="btn-cancel" onclick="hideBookForm()">Cancel</button>
        </form>
    </div>

    <script>
        function showBookForm(roomId, roomNumber) {
            document.getElementById('room_id').value = roomId;
            document.getElementById('roomNumber').innerText = roomNumber;
            document.getElementById('bookForm').style.display = 'block';
        }
        function hideBookForm() {
            document.getElementById('bookForm').style.display = 'none';
        }
    </script>
</body>
</html>